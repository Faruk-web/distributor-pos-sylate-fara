# print-receipt-thermal-printer
 Example to print a ticket or receipt by using CSS, HTML & JavaScript only
 With this, you can print a receipt that looks like this:

![Ticket printed by using CSS HTML & JS only](https://raw.githubusercontent.com/parzibyte/print-receipt-thermal-printer/master/ticket-sample.jpg)

Tutorial here: https://parzibyte.me/blog/en/2019/10/10/print-receipt-thermal-printer-javascript-css-html/